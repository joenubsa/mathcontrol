var Modulo = function () {
    var resultContainer = 'tblProgreso';
    var formulario = $('#progreso');
    var module = "progreso";
    var moduleFunctions = new ModuleFunctions(this);
    var moduleEvents = new ModuleEvents(this);
    this.ModuleFunctions = moduleFunctions;
    this.inicializarFormulario = function () {
        $('#id').hide();
        $('#cmdIniciarPrueba, .cuestionario-container').hide();
        inicializarEventos();        
        moduleFunctions.validarModulosCondicionados();
        //app.consultar();
    };

    var inicializarEventos = function () {
        $('.modulo-icon').on('click', moduleEvents.accionesModulo);
        $('#cmdResumen').on('click', function () {
            document.location = "/?modulo=temario";
        });
        $('#cmdAvanzar').on('click', function () {
            moduleFunctions.avanzarAction();
            $("#" + sessionStorage.currentModulo).trigger('click');
            $("body").animate({ scrollTop: 0 }, 1000);
            
        });
        $('#cmdTerminarPrueba').on('click', function(){
            moduleFunctions.finalizarCuestionario();
        });
        
        $('#cmdfVertical').on('click', function() {
            moduleFunctions.consultarArticulo(sessionStorage.currentModulo, 20);
        });
        
        $('#cmdfHorizontal').on('click', function() {
            moduleFunctions.consultarArticulo(sessionStorage.currentModulo, 21);
        });

    };


    this.cargarFormulario = function (r) {
//        var valores = r;
//        $('#id').val(valores[0]['id']);
//        $('#nombre').val(valores[0]['nombre']);
//        $('#descripcion').val(valores[0]['descripcion']);
//        $('#modulo_id').val(valores[0]['modulo_id']);
//        $('#progreso_id').val(valores[0]['progreso_id']);
//        $('#estado').val(valores[0]['estado']);
    };

    this.onCargarFormulario = function (r) {

    };

    this.procesarConsulta = function (r, c, e) {
        switch (c) {
            case "articulo_actual":
                moduleFunctions.renderizarArticulo(r.content[0]);
                moduleFunctions.verificarCuestionario(r.content[0].id);
                break;
            case "verificar_cuestionario":
                if (r.content.length > 0){
                    $('#cmdIniciarPrueba').show();
                    $('#cmdIniciarPrueba').on('click', function(){
                        moduleFunctions.renderizarCuestionario(r.content[0]);
                    });
                } else {
                    $('#cmdIniciarPrueba').hide();
                }
                break;
            case "traer_cuestionario":
                //moduleFunctions.renderizarCuestionario(r.content[0]);
                break;
            case "renderizar_menu":
                moduleFunctions.renderizarMenu(r.content);
                break;
            case "result_":
                switch (e) {
                    case "validarModulosCondicionados":
                        if (r.content === true) {
                            $('.modulos .condicionados').show();
                        }
                        break;
                }
                break;
            
        }
    };

    this.onCargaTabla = function (c) {
        switch (c) {

        }
    };

    this.getResultContainer = function () {
        return resultContainer;
    };

    this.getFormulario = function () {
        return formulario;
    };

    this.getModule = function () {
        return module;
    };

    var app = new Application(this);
    this.getApp = function () {
        return app;
    };
};

var ModuleFunctions = function (modulo) {
    var app;
    this.consultarArticulo = function (moduloId, articuloId) {
        app = modulo.getApp();
        articuloId = (articuloId || false);
        var args = {
            modulo: moduloId,
            mostraractual: articuloId
        };
        app.consultar(null, 'articulo_actual', 'articulo_actual', args);
        app.consultar(null, 'renderizar_menu', 'renderizar_menu', args); 
    };
    
    this.verificarCuestionario = function (articulo_id) {
        app = modulo.getApp();
        var args = {
            articulo_id: articulo_id
        };
        app.consultar(null, 'verificar_cuestionario', 'verificar_cuestionario', args);
    };

    this.consultarCuestionario = function (articulo_id) {
        app = modulo.getApp();
        var args = {
            articulo_id: articulo_id
        };
        app.consultar(null, 'traer_cuestionario', 'traer_cuestionario', args);
    };

    this.renderizarArticulo = function (r) {        
        $('.progreso_articulo-container input[name=articulo_id]').val(r.id);
        $('.progreso_articulo-container .titulo').html(r.nombre);
        $('.progreso_articulo-container .cuerpo .contenido').html(r.descripcion);
        if (+r.id === 19) {
            $('.progreso_articulo-container .acciones .especial').show();
        } else {
            $('.progreso_articulo-container .acciones .especial').hide();
        }
    };

    this.renderizarCuestionario = function (r) {
        $('.cuestionario-container').show();
        var preguntasCollection = JSON.parse(r.cuerpo);
        var cantidadPreguntas = preguntasCollection.length;
        var esEntrenamiento = +r.esEntrenamiento;        
        var seleccion = [];
        var numpreg = esEntrenamiento === 1 ? 1 : 10;
        for (var i = 0; i < numpreg; i++) {
            var seRepite = false;
            do {
                seRepite = false;
                var pregSeleccionada = Math.floor((Math.random() * cantidadPreguntas));
                for (var k in seleccion) {
                    if (seleccion[k] === pregSeleccionada) {
                        seRepite = true;
                    }
                }
                if (!seRepite) {
                    seleccion [i] = pregSeleccionada;
                }
            } while (seRepite);
        }

        var contenedorMaestro = $('.cuestionario .pregunta:first-child').clone();
        $('.cuestionario').attr('data-id', r.id);
        $('.cuestionario .pregunta').remove();
        for (var i in seleccion) {
            var preguntaHTML = contenedorMaestro.clone();
            var pregunta = preguntasCollection[seleccion[i]];
            $('.cuestionario').append(preguntaHTML);
            preguntaHTML.attr('data-id', pregunta.id);
            preguntaHTML.find('.texto').html(decodeURI(pregunta.texto));
            preguntaHTML.find('.respuestas').html(pregunta.respuestas);
            var respuestasOl = $('<ol>').attr('type', 'a');
            for (var k in pregunta.respuestas) {
                var respuesta = pregunta.respuestas[k];
                var label = $('<label>');
                var input = $('<input>').attr('type', 'radio').attr('data-validate', respuesta.correcta).attr('name', 'pregunta_' + pregunta.id).val(respuesta.id);
                label.append(input);
                $('<span>').html(decodeURI(respuesta.texto)).appendTo(label);
                $('<li>').append(label).appendTo(respuestasOl);
                
            }
            if (esEntrenamiento === 1) {
                preguntaHTML.find('.preguntaacciones').html('');
                preguntaHTML.find('.preguntaacciones').append('<button type="button">Pasos</button>'+
                    '<button type="button">Ejercicios Modelo</button>'+
                    '<button type="button">Ejercicio Resuelto</button>'+
                    '<button type="button">Ver mi resultado</button>'+
                    '<button type="button" id="cmdOtroEjercicio">Otro Ejercicio</button>'+
                    '<button type="button">Iniciar entrenamiento de problemas</button>'+
                    '<button type="button">Iniciar Evaluación</button>');
            }
            respuestasOl.appendTo(preguntaHTML.find('.respuestas'));
            
            $('#cmdOtroEjercicio').off('click');
            $('#cmdOtroEjercicio').on('click', function(){
                $('#cmdIniciarPrueba').trigger('click');
            });
        }
    };

    this.avanzarAction = function () {
        app = modulo.getApp();
        var args = {
            articulo_id: $('input[name=articulo_id]').val()
        };
        app.ejecutar('avanzarAction', args);
    };
    
    this.validarModulosCondicionados = function() {
        app = modulo.getApp();
        app.ejecutar('validarModulosCondicionados');
    };

    this.finalizarCuestionario = function () {
        var respuestas = {
                id: $('.cuestionario').data('id'),
                cuerpo: []
        };
        var sinCompletar = false;
        $('.cuestionario').find('.pregunta').each(function () {
            var respuestaInput = $(this).find('input:checked');
            if (!respuestaInput.val() || respuestaInput.val() === '') {
                sinCompletar = true;
            } else {
                respuestas.cuerpo.push({
                    id: $(this).data('id'),
                    rta_id: respuestaInput.val(),
                    rta_validate: respuestaInput.data('validate')
                });
            }
        });

        if (sinCompletar) {
            alert('Debes completar el cuestionario antes de enviarlo');
            return false;
        } else {
            alert('Has completado el cuestionario satisfactoriamente');
            $('.cuestionario-container').hide();
        }

        var args = {
            cuestionario_id: $('.cuestionario').data('id'),
            respuestas : JSON.stringify(respuestas)
        };
        app.ejecutar('terminarPruebaAction', args);
        this.validarModulosCondicionados();
    };
    
    this.renderizarMenu = function(r){
        $('.progreso_articulo-container .cuerpo .menu').find('ul').remove();
        var menuhtml = $('<ul>').appendTo('.progreso_articulo-container .cuerpo .menu');
        var modulo = this;
        for (var i in r) {
            var item = r[i];
            $('<li>').attr('data-articulo', item.id).html(item.nombre).on('click', function(){
                var moduloId = sessionStorage.currentModulo;
                modulo.consultarArticulo(moduloId, $(this).data('articulo'));
            }).appendTo(menuhtml);
        }
    };    
    

};

var ModuleEvents = function (modulo) {
    this.accionesModulo = function (event) {
        var moduloId = $(event.target).attr('id');
        modulo.ModuleFunctions.consultarArticulo(moduloId);
        modulo.ModuleFunctions.validarModulosCondicionados();
        sessionStorage.currentModulo = moduloId;
    };

};
